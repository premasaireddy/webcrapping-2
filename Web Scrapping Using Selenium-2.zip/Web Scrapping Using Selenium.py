#!/usr/bin/env python
# coding: utf-8

# # 1

# In[ ]:


#intializing selenium and web driver

import selenium
from selenium import webdriver
import pandas as pd
driver = webdriver.Chrome('/Users/prema/Downloads/chromedriver_win32/chromedriver.exe')
driver.get('https://www.naukri.com')
#Accessing Rale and location boxes
Role = driver.find_element_by_xpath("//input[@name='keyword']")
Location=driver.find_element_by_xpath("//input[@name='location']")
su=driver.find_element_by_xpath("//button[@class='btn']")
Role.clear()
Location.clear()
#givng required role and location
Role.send_keys('Data Analyst')
Location.send_keys('Bangalore')
su.submit()
#waiting to search as per given requirements
driver.implicitly_wait(5)
#getting required details like comnapny,location ...
job_title=[]
for i in driver.find_elements_by_xpath("//a[@class='title fw500 ellipsis']"):
    job_title.append(i.text)
job_location=[]
for i in driver.find_elements_by_xpath("//li[@class='fleft grey-text br2 placeHolderLi location']"):
       for k in i.find_elements_by_tag_name("span"):
            job_location.append(k.get_attribute('title'))
Company=[]
for i in driver.find_elements_by_xpath("//div[@class='mt-7 companyInfo subheading lh16']"):
    for j in i.find_elements_by_tag_name("a"):
        Company.append(j.get_attribute('title'))
        break
experience=[]
for i in driver.find_elements_by_xpath("//li[@class='fleft grey-text br2 placeHolderLi experience']"):
    for j in i.find_elements_by_tag_name("span"):
        experience.append(j.get_attribute('title'))
##creating data frame for the above collected data
data={'JobTitle':job_title[:],'JobLocation':job_location[:],'Company':Company[:],'Experience':experience[:]}
op=pd.DataFrame(data)
op.style.hide_index()


# # 2

# In[ ]:


#intializing selenium and web driver

import selenium
from selenium import webdriver
import pandas as pd
driver = webdriver.Chrome('/Users/prema/Downloads/chromedriver_win32/chromedriver.exe')
driver.get('https://www.naukri.com')
#sending input key words to corresponding search boxes

Role = driver.find_element_by_xpath("//input[@name='keyword']")
Location=driver.find_element_by_xpath("//input[@name='location']")
su=driver.find_element_by_xpath("//button[@class='btn']")
Role.clear()
Location.clear()
#givng required role and location
Role.send_keys('Data Analyst')
Location.send_keys('Bangalore')
su.submit()
driver.implicitly_wait(5)
#getting the link of jobs as per the given requirements as per above
job=[]
for i in driver.find_elements_by_xpath("//a[@class='title fw500 ellipsis']"):
        job.append(i.get_attribute('href'))
job=job[:10]
#getting the text out of the above gathered references 
jd=[]
for i in range(0,len(job)):
    a=job[i]
    driver.get(a)
    d = driver.find_elements_by_xpath("//div[@class='dang-inner-html']")
    for i in d:
        temp=i.find_elements_by_tag_name('p')
        jd.append(i.text)
   


# # 3

# In[ ]:


#intializing selenium and web driver

import selenium
from selenium import webdriver
import pandas as pd
import time
driver = webdriver.Chrome('/Users/prema/Downloads/chromedriver_win32/chromedriver.exe')
driver.get('https://www.naukri.com/')
driver.maximize_window()
#sending input key words to corresponding search boxes
Role = driver.find_element_by_xpath("//input[@name='keyword']")
su=driver.find_element_by_xpath("//button[@class='btn']")
Role.clear()
#givng required role and location
Role.send_keys('Data Analyst')
su.submit()
time.sleep(5)
driver.find_element_by_xpath("//span[@title='Bangalore/Bengaluru']").click()
time.sleep(5)
driver.find_element_by_xpath("//span[@title='3-6 Lakhs']").click()
time.sleep(5)
#collecting data as per requirement
c,e,s=[],[],[]
try:
    for i in driver.find_elements_by_xpath("//div[@class='mt-7 companyInfo subheading lh16']"):
        c.append(i.find_element_by_tag_name('a').text)
except:
    c.append('NA')
try:
    for i in driver.find_elements_by_xpath("//li[@class='fleft grey-text br2 placeHolderLi experience']"):
        e.append(i.find_element_by_tag_name('span').text)
except:
    e.append('NA')
try:
    for i in driver.find_elements_by_xpath("//li[@class='fleft grey-text br2 placeHolderLi salary']"):
        s.append(i.find_element_by_tag_name('span').text)
except:
    s.append('NA')
data={'Comapny':c[:10],'Salary':s[:10],'Experience':e[:10]}
op=pd.DataFrame(data)
op


# # 4

# In[ ]:


#intializing selenium and web driver

import selenium
from selenium import webdriver
import pandas as pd
driver = webdriver.Chrome('/Users/prema/Downloads/chromedriver_win32/chromedriver.exe')
driver.get(' https://www.glassdoor.co.in/index.htm')
sign=driver.find_element_by_xpath("//button[@class='d-none d-lg-block p-0 LockedHomeHeaderStyles__signInButton']")
sign.click()
#sending input key words to corresponding search boxes
email=driver.find_element_by_id('userEmail')
email.clear()
email.send_keys('kurrepremasaireddy@gmail.com')
password=driver.find_element_by_id('userPassword')
password.clear()
password.send_keys('Premasaireddy')
driver.find_element_by_xpath("//button[@class='gd-ui-button minWidthBtn css-8i7bc2']").click()
driver.implicitly_wait(3)
#location=driver.find_element_by_id('sc.location')
title=driver.find_element_by_id('sc.keyword')
title.clear()
title.send_keys('Data Scientist')
#location.send_keys('Noida(India)')
driver.find_element_by_xpath("//button[@class='gd-ui-button ml-std col-auto SearchStyles__newSearchButton css-iixdfr']").click()
driver.implicitly_wait(3)
location=driver.find_element_by_id('sc.location')
location.clear()
location.send_keys('Noida(India)')
driver.find_element_by_xpath("//button[@class='gd-ui-button ml-std col-auto SearchStyles__newSearchButton css-iixdfr']").click()
driver.implicitly_wait(3)
#collecting data as per requirement
company=[]
for i in driver.find_elements_by_xpath("//a[@class=' css-l2wjgv e1n63ojh0 jobLink']"):
    a = i.find_element_by_tag_name('span')
    company.append(a.text)
len(company)
job_title=[]
for i in driver.find_elements_by_xpath("//a[@class='jobLink css-1rd3saf eigr9kq2']"):
    a = i.find_element_by_tag_name('span')
    job_title.append(a.text)
len(job_title)
Fresh=[]
for i in driver.find_elements_by_xpath("//div[@class='d-flex align-items-end pl-std css-mi55ob']"):
    a=i.text
    a= a.replace('d',' days')
    Fresh.append(a)
data={'Company name':company,"Title":job_title,'Age of the job post':Fresh}
op=pd.DataFrame(data)
op.style.hide_index()


# # 5

# In[ ]:


#intializing selenium and web driver

import selenium
from selenium import webdriver
import pandas as pd
driver = webdriver.Chrome('/Users/prema/Downloads/chromedriver_win32/chromedriver.exe')
driver.get(' https://www.glassdoor.co.in/Salaries/index.htm')
sign=driver.find_element_by_xpath("//button[@class='d-none d-lg-block p-0 LockedHomeHeaderStyles__signInButton']")
sign.click()
#sending input key words to corresponding search boxes
email=driver.find_element_by_id('userEmail')
email.clear()
email.send_keys('kurrepremasaireddy@gmail.com')
password=driver.find_element_by_id('userPassword')
password.clear()
password.send_keys('Premasaireddy')
driver.find_element_by_xpath("//button[@class='gd-ui-button minWidthBtn css-8i7bc2']").click()
driver.implicitly_wait(3)
tit=driver.find_element_by_id('KeywordSearch')
tit.send_keys('Data Scientist')
loc=driver.find_element_by_id('LocationSearch')
loc.clear()
loc.send_keys('Noida')
driver.find_element_by_xpath("//button[@class='gd-btn-mkt']").click()
driver.implicitly_wait(3)
driver.execute_script("window.scrollTo(0, document.body.scrollHeight);")
driver.implicitly_wait(3)
#collecting data as per requirement
company=[]
for i in driver.find_elements_by_xpath("//a[@class='css-f3vw95 e1aj7ssy3']"):
    company.append(i.text)
sal,min,max=[],[],[]
for i in driver.find_elements_by_xpath("//div[@class='d-flex mt-xxsm css-79elbk epuxyqn0']"):
    for j in i.find_elements_by_tag_name('p'):
        sal.append(j.text)
for i in range(0,len(sal),2):
    min.append(sal[i])
for i in range(1,len(sal),2):
    max.append(sal[i])
rat=[]
for i in driver.find_elements_by_xpath("//span[@class='m-0 css-kyx745']"):
    rat.append(i.text)
len(rat)
avg=[]
for i in driver.find_elements_by_xpath("//div[@class='col-12 col-lg-4 px-lg-0 d-flex align-items-baseline']"):
    for j in i.find_elements_by_tag_name('h3'):
        avg.append(j.text)
driver.implicitly_wait(3)

data={'Comapny':company,"minimum salary":min,"maximum salary":max,'Average salary':avg,'Rating':rat}
op=pd.DataFrame(data)
op.style.hide_index()


# # 6

# In[ ]:


#intializing selenium and web driver

import selenium
from selenium import webdriver
import pandas as pd
driver = webdriver.Chrome('/Users/prema/Downloads/chromedriver_win32/chromedriver.exe')
driver.get('https://www.flipkart.com/')
driver.implicitly_wait(3)
#sending input key words to corresponding search boxes
driver.find_element_by_xpath("//button[@class='_2KpZ6l _2doB4z']").click()
driver.maximize_window()
pro=driver.find_element_by_xpath("//input[@class='_3704LK']")
pro.clear()
pro.send_keys('sunglasses')
driver.find_element_by_xpath("//button[@class='L0Z3Pu']").submit()
#collecting data as per requirement
offer,company,price,about=[],[],[],[]
while len(price)<100:
    try:
        for i in driver.find_elements_by_xpath("//div[@class='_2WkVRV']"):
            company.append(i.text)
    except:
        company.append('NA')
    try:    
        for i in driver.find_elements_by_xpath("//div[@class='_30jeq3']"):
            price.append(i.text)
    except:
        price.append('NA')
    try:
        for i in driver.find_elements_by_xpath("//div[@class='_3Ay6Sb']"):
            try:
                for j in i.find_elements_by_tag_name('span'):
                    offer.append(j.text)
            except:
                offer.append('NA')
    except:
        offer=offer
    try:
        for i in driver.find_elements_by_xpath("//a[@class='IRpwTa']"):
            about.append(i.text)
    except:
        about.append('NA')
    try:
        driver.find_element_by_xpath("//a[@class='_1LKTO3']").click()
        driver.implicitly_wait(3)
    except:
        a=driver.find_elements_by_xpath("//a[@class='_1LKTO3']")
        a[1].click()
        driver.implicitly_wait(3)
data={'Company':company,'Price':price,'offer':offer,'Description':about}
op=pd.DataFrame(data)
op


# # 7

# In[ ]:


#intializing selenium and web driver

import selenium
from selenium import webdriver
import pandas as pd
driver = webdriver.Chrome('/Users/prema/Downloads/chromedriver_win32/chromedriver.exe')
driver.get('https://www.flipkart.com/apple-iphone-11-black-64-gb-includes-earpods-power-adapter/p/itm0f37c2240b217?pid=MOBFKCTSVZAXUHGR&lid=LSTMOBFKCTSVZAXUHGREPBFGI&marketplace')
driver.maximize_window()
driver.find_element_by_xpath("//div[@class='_3UAT2v _16PBlm']").click()
#collecting data as per requirement
rating,rs,fr = [],[],[]
while len(rating)<100:
    driver.implicitly_wait(3)
    try:
        for i in driver.find_elements_by_xpath("//div[@class='_3LWZlK _1BLPMq']"):
            rating.append(i.text)
    except:
        rating.append('NA')
    try:
        for i in driver.find_elements_by_xpath("//p[@class='_2-N8zT']"):
            rs.append(i.text)
    except:
        rs.append('NA')
    try:
        for i in driver.find_elements_by_xpath("//div[@class='']"):
            fr.append(i.text)
    except:
        fr.append('NA')
    try:
        a=driver.find_elements_by_xpath("//a[@class='_1LKTO3']")
        a[1].click()
    except:
        a=driver.find_elements_by_xpath("//a[@class='_1LKTO3']")
data={'Rating':rating,'Review Summary':rs,'Full Review':fr}
op=pd.DataFrame(data)
op


# # 8

# In[ ]:


#intializing selenium and web driver

import selenium
from selenium import webdriver
import pandas as pd
driver = webdriver.Chrome('/Users/prema/Downloads/chromedriver_win32/chromedriver.exe')
driver.get("https://www.flipkart.com/")
driver.find_element_by_xpath("//button[@class='_2KpZ6l _2doB4z']").click()
driver.maximize_window()
#sending input key words to corresponding search boxes
sne=driver.find_element_by_xpath("//input[@class='_3704LK']")
sne.clear()
sne.send_keys('sneakers')
driver.find_element_by_xpath("//button[@class='L0Z3Pu']").submit()
#collecting data as per requirement
p,b,d,ds,a=[],[],[],[],100
while min(len(p),len(b),len(d),len(ds)) < 100:
    try:
        for i in driver.find_elements_by_xpath("//div[@class='_2WkVRV']"):
            b.append(i.text)
    except:
        b.append('NA')
    try:    
        for i in driver.find_elements_by_xpath("//div[@class='_30jeq3']"):
            p.append(i.text)
    except:
        p.append('NA')
    try:
        for i in driver.find_elements_by_xpath("//div[@class='_3Ay6Sb']"):
            try:
                for j in i.find_elements_by_tag_name('span'):
                    d.append(j.text)
            except:
                d.append('NA')
    except:
        d=d
    try:
        for i in driver.find_elements_by_xpath("//a[@class='IRpwTa']"):
            ds.append(i.text)
    except:
        ds.append('NA')
    try:
        driver.find_element_by_xpath("//a[@class='_1LKTO3']").click()
        driver.implicitly_wait(3)
    except:
        a=driver.find_elements_by_xpath("//a[@class='_1LKTO3']")
        a[1].click()
        driver.implicitly_wait(3)
data={'Brand':b[:a],'Price':p[:a],'Discount':d[:a],'Description':ds[:a]}
op=pd.DataFrame(data)
op


# # 9

# In[ ]:


#intializing selenium and web driver

import selenium
from selenium import webdriver
import pandas as pd
import time
driver = webdriver.Chrome("/Users/prema/Downloads/chromedriver_win32/chromedriver.exe")
#sending input key words to corresponding search boxes
driver.get("https://www.myntra.com/shoes")
driver.maximize_window()
driver.implicitly_wait(6)
driver.find_element_by_xpath('/html/body/div[2]/div/div[1]/main/div[3]/div[1]/section/div/div[6]/ul/li[1]/label/div').click()
time.sleep(3)
driver.find_element_by_xpath('/html/body/div[2]/div/div[1]/main/div[3]/div[1]/section/div/div[5]/ul/li[2]/label/div').click()
time.sleep(3)
#collecting data as per requirement
p,b,pds=[],[],[]
while(len(p)<100):
    try:
        for i in driver.find_elements_by_xpath("//div[@class='product-price']"):
            p.append(i.text)
    except:
        p.append('NA')
    try:
        for i in driver.find_elements_by_xpath("//h3[@class='product-brand']"):
            b.append(i.text)
    except:
        b.append('NA')
    try:
        for i in driver.find_elements_by_xpath("//h4[@class='product-product']"):
            pds.append(i.text)
    except:
        pds.append('NA')
        
    driver.find_element_by_xpath("//li[@class='pagination-next']").click()
    time.sleep(5)
data={'Price':p,'Brand':b,'ProductDescription':pds}
op=pd.DataFrame(data)
op


# # 10

# In[1]:


#intializing selenium and web driver

import selenium
from selenium import webdriver
import pandas as pd
import time
driver = webdriver.Chrome("/Users/prema/Downloads/chromedriver_win32/chromedriver.exe")
#sending input key words to corresponding search boxes
driver.get("https://www.amazon.in")
driver.maximize_window()
driver.find_element_by_xpath("//input[@class='nav-input nav-progressive-attribute']").send_keys('Laptop')
driver.find_element_by_xpath("//input[@id='nav-search-submit-button']").click()
time.sleep(2)
driver.find_element_by_xpath("/html/body/div[1]/div[2]/div[1]/div/div[2]/div/div[3]/span/div[1]/span/div/div/div[6]/ul[1]/li[26]/span/a/span").click()
time.sleep(3)
driver.find_element_by_xpath("/html/body/div[1]/div[2]/div[1]/div/div[2]/div/div[3]/span/div[1]/span/div/div/div[6]/ul[1]/li[27]/span/a/span").click()
time.sleep(3)
#collecting data as per requirement
t,p,r,f=[],[],[],[]
try:
    for i in driver.find_elements_by_xpath("//span[@class='a-size-medium a-color-base a-text-normal']"):
        t.append(i.text)
except:
    t.append('NA')
try:
    for i in driver.find_elements_by_xpath("//span[@class='a-price-whole']"):
        p.append(i.text)
except:
    p.append('NA')
for i in driver.find_elements_by_xpath("//a[@class='a-link-normal a-text-normal']"):
    f.append(i.get_attribute('href'))
len(f)
for i in range(0,len(f)):
    driver.get(f[i])
    try:
        driver.find_element_by_xpath("//span[@id='acrCustomerReviewText']").click()
        time.sleep(3)
        t=driver.find_element_by_xpath("//span[@data-hook='rating-out-of-text']")
        r.append(t.text)
    except:
        r=r
data={'Title':t[:10],'Price':p[:10],'Rating':r[:10]}
op=pd.DataFrame(data)
op

